﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;

namespace LikhoAi
{//start of namespace

    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {//start of class

        //creating an instance for the class Array
        ArrayList reply = new ArrayList();
        ArrayList ignore = new ArrayList();
        user_name check_name = new user_name();

        // variables
        string username = string.Empty;
        int counting = 0;

        //creating a class training with an object name train_ai
        training train_ai = new training();

        //for the tasks class with database to add task for reminder
        tasks manage_tasks = new tasks();
        //global variable to hold the task details
        string task_name = string.Empty, task_description = string.Empty, task_dueDate = string.Empty, task_status = string.Empty;

        // Tracks the current quiz question index
        int currentQuestionIndex = 0;

        // Holds the user's current quiz score
        int score = 0;

        // Stores the user's currently selected answer.
        // BUG FIX: this used to be initialized to null but answerButton() compared it to
        // string.Empty, so the "please select an answer" check could never fire.
        string selectedAnswer = string.Empty;

        // Stores the list of answer buttons for the current quiz question
        List<Button> answerButtons;

        // Holds the entire list of quiz questions.
        // (Renamed from "questions" to "quizQuestions" so it can no longer be shadowed by
        // the "questions" parameter/local variable used elsewhere for chat input.)
        List<Question_in_quiz> quizQuestions;

        // Handles loading quiz questions from storage or file
        Quiz_Question_Load load_Quiz = new Quiz_Question_Load();

        public MainWindow()
        {//constructor
            InitializeComponent();

            //store answers
            new respond(reply, ignore);

            //train NLP on the run
            train_ai.Train();
            manage_tasks.CreateTableIfNotExists();

            //creating an instance for the class voice_greeting
            //with an object name greet
            voice_greeting greet = new voice_greeting();

            //call the voice method
            greet.greet();

            // Dynamically add all quiz answer buttons to the UI
            addAllButtons();

            // Load quiz questions automatically into the 'quizQuestions' list
            load_Quiz.autoLoadQuiz(ref quizQuestions);

            // Load the first question into the UI
            loadQuestions();

        }//end of constructor




        // ---------------------------------------------------------------
        // Page navigation
        // ---------------------------------------------------------------

        private void proceed(object sender, RoutedEventArgs e)
        {//event handler for the proceed button
         //this will hide the home page and show the username page

            home_grid.Visibility = Visibility.Hidden;
            username_grid.Visibility = Visibility.Visible;

        }//end of event handler

        private void submit_username(object sender, RoutedEventArgs e)
        {//event handler for the submit username button
         //this will save the username and proceed to the chat interface

            // get username from textbox
            string enteredUsername = usernames_input.Text.Trim();

            // check if username is empty
            if (string.IsNullOrWhiteSpace(enteredUsername))
            {
                MessageBox.Show("Enter username", "Username Required",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                return;
            }

            //check the user name from memory recall
            username = check_name.submit_name(usernames_input, chats);

            //Hide username page grid and set the main page visible
            username_grid.Visibility = Visibility.Hidden;
            MainPage.Visibility = Visibility.Visible;

        }//end of event handler

        // Switch to the Chats page
        private void chatting(object sender, RoutedEventArgs e)
        {
            chat_page.Visibility = Visibility.Visible;
            HistoryPage.Visibility = Visibility.Hidden;
            reminderPage.Visibility = Visibility.Hidden;
            LogPage.Visibility = Visibility.Hidden;
            gamePage.Visibility = Visibility.Hidden;
        }

        // Switch to the Reminders page
        private void reminders(object sender, RoutedEventArgs e)
        {
            chat_page.Visibility = Visibility.Hidden;
            HistoryPage.Visibility = Visibility.Hidden;
            reminderPage.Visibility = Visibility.Visible;
            LogPage.Visibility = Visibility.Hidden;
            gamePage.Visibility = Visibility.Hidden;

            //call the auto load task method, to show all the tasks
            autoLoad_task();
        }

        // Switch to the History page
        private void history(object sender, RoutedEventArgs e)
        {
            chat_page.Visibility = Visibility.Hidden;
            HistoryPage.Visibility = Visibility.Visible;
            reminderPage.Visibility = Visibility.Hidden;
            LogPage.Visibility = Visibility.Hidden;
            gamePage.Visibility = Visibility.Hidden;

            //show the user's stored interests on the history page
            loadHistory();
        }

        // Switch to the Activity Log page
        private void activity(object sender, RoutedEventArgs e)
        {
            chat_page.Visibility = Visibility.Hidden;
            HistoryPage.Visibility = Visibility.Hidden;
            reminderPage.Visibility = Visibility.Hidden;
            LogPage.Visibility = Visibility.Visible;
            gamePage.Visibility = Visibility.Hidden;
        }

        // Switch to the Game page
        private void game(object sender, RoutedEventArgs e)
        {
            chat_page.Visibility = Visibility.Hidden;
            HistoryPage.Visibility = Visibility.Hidden;
            reminderPage.Visibility = Visibility.Hidden;
            LogPage.Visibility = Visibility.Hidden;
            gamePage.Visibility = Visibility.Visible;
        }

        // Exit the application
        private void exit(object sender, RoutedEventArgs e)
        {
            System.Environment.Exit(0);
        }




        // ---------------------------------------------------------------
        // Quiz game
        // ---------------------------------------------------------------

        private void addAllButtons()
        {
            answerButtons = new List<Button> {
                optionButtonOne,
                optionButtonTwo,
                optionButtonThree,
                optionButtonFour
            };
        }//end of code

        private void buttonReset()
        {
            foreach (Button clickButton in answerButtons)
            {
                clickButton.ClearValue(Button.BackgroundProperty);
                clickButton.Background = System.Windows.Media.Brushes.Gray;
            }
        }

        private void loadQuestions()
        {
            //checking if the user has completed the quiz
            if (currentQuestionIndex >= quizQuestions.Count)
            {
                MessageBox.Show("Great job! You've completed the quiz with a score of " + score + ".\nThe game will now reset. Press OK to continue.");
                currentQuestionIndex = 0;
                score = 0;
                selectedAnswer = string.Empty;
                loadQuestions();
                return;
            }

            //get the question
            var foundQuestion = quizQuestions[currentQuestionIndex];
            question_asked.Text = foundQuestion.Text;

            //setting up the score
            score_count.Text = "score.." + "\n" + score;

            //resetting the selected answer
            selectedAnswer = string.Empty;

            //resetting the buttons
            buttonReset();

            //randomizing answers
            List<string> allAnswers = new List<string>(foundQuestion.wrongAnswer);
            allAnswers.Add(foundQuestion.correctAnswer);

            Random getIndex = new Random();
            for (int count = 0; count < allAnswers.Count; count++)
            {
                int found_index = getIndex.Next(count, allAnswers.Count);
                (allAnswers[count], allAnswers[found_index]) = (allAnswers[found_index], allAnswers[count]);
            }

            //assigning answers to the buttons
            for (int count = 0; count < answerButtons.Count; count++)
            {
                answerButtons[count].Content = allAnswers[count];
            }

        }//end of code

        private void optionSelected(object sender, RoutedEventArgs e)
        {
            buttonReset();
            Button clickButton = sender as Button;
            clickButton.Background = System.Windows.Media.Brushes.Green;
            selectedAnswer = clickButton.Content.ToString();
        }

        private void answerButton(object sender, RoutedEventArgs e)
        {
            //checking if the user selected an option first
            //(BUG FIX: selectedAnswer was initialized to null but compared against
            //string.Empty, so this guard never actually triggered)
            if (string.IsNullOrEmpty(selectedAnswer))
            {
                MessageBox.Show("please select an answer!");
                return;
            }

            if (selectedAnswer == quizQuestions[currentQuestionIndex].correctAnswer)
            {
                score += 5;
            }

            currentQuestionIndex++;
            loadQuestions();

        }//end of quiz




        // ---------------------------------------------------------------
        // Tasks / reminders
        // ---------------------------------------------------------------

        // Handles double-clicking on an item in the reminder list
        private void remind_append_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (view_tasks.SelectedValue == null)
                return;

            string get_selected_value = view_tasks.SelectedValue.ToString();

            //BUG FIX: the id used to be read with Substring(0, 1), which only works while
            //task ids stay single-digit. Splitting on the first space supports any id length.
            string get_id = get_selected_value.Split(' ')[0];

            if (!int.TryParse(get_id, out int id))
                return;

            //check if the selected task ends with "done", then delete if it does
            if (get_selected_value.ToLower().EndsWith("done"))
            {
                manage_tasks.delete_task(id);
            }
            else
            {
                //mark it done since it is currently "pending"
                manage_tasks.update_taskStatus(id);
            }

            //recall the auto load method
            autoLoad_task();
        }

        //method to auto load the Tasks of a user
        private void autoLoad_task()
        {
            view_tasks.Items.Clear();
            manage_tasks.load_tasks(view_tasks);
        }

        //method to show the user's stored interests on the History page
        private void loadHistory()
        {
            history_append.Items.Clear();

            string filename = "interested_topic.txt";
            if (File.Exists(filename))
            {
                foreach (string line in File.ReadAllLines(filename))
                {
                    if (!string.IsNullOrWhiteSpace(line))
                        history_append.Items.Add(line);
                }
            }

            if (history_append.Items.Count == 0)
                history_append.Items.Add("No history yet.");
        }




        // ---------------------------------------------------------------
        // Chat
        // ---------------------------------------------------------------

        //send event handler
        private void send(object sender, RoutedEventArgs e)
        {
            // Get the question from the design and sanitize it
            string rawQuestion = question.Text.ToString();

            if (string.IsNullOrWhiteSpace(rawQuestion))
            {
                error_method("LikhoAi", "Please enter a question.");
                return;
            }

            // Remove special characters and clean the question
            string cleanedQuestion = RemoveSpecialCharacters(rawQuestion);

            // Show what the user typed
            error_method(username, rawQuestion);

            //ai chats and auto_show_interest
            auto_show_interest();
            ai_check(cleanedQuestion);
        }

        //start of ai_chat method
        private void ai_check(string questions)
        {
            // Check if user entered anything meaningful
            if (string.IsNullOrWhiteSpace(questions))
            {
                error_method("LikhoAi", "Please enter a valid question.");
                question.Clear();
                return;
            }

            // Variables for processing
            string[] words = questions.ToLower().Split(new char[] { ' ', ',', '.', '?', '!', ';', ':' }, StringSplitOptions.RemoveEmptyEntries);
            bool found = false;
            string message = string.Empty;
            Random indexer = new Random();
            List<string> per_word = new List<string>();
            List<string> answers_found = new List<string>();

            if (questions.ToLower().StartsWith("add task"))
            {//start of if add task

                //add the task to the listview as part of the chats
                message += "Great your task is added, would you like a reminder?\n and also ";

                //then filter to get task name
                task_name = questions.Replace("add task", "");

            }//end of if checking task add or add task

            //check if the user wants to set a reminder
            if (questions.ToLower().StartsWith("yes, remind me in") || questions.ToLower().StartsWith("yes remind me in"))
            {//start of the reminder if

                string reminder = questions.Replace("yes, remind me in", "");
                string days_number = Regex.Replace(reminder, @"[^0-9]", "");

                if (!int.TryParse(days_number, out int days))
                {
                    error_method("LikhoAi", "Sorry, I couldn't tell how many days you meant. Try again, e.g. 'yes remind me in 3 days'.");
                    question.Clear();
                    return;
                }

                DateTime user_reminder = DateTime.Now.AddDays(days);
                string format_date = user_reminder.ToString("MMMM dd yyyy");

                task_dueDate = format_date;
                task_status = "pending";

                error_method("LikhoAi", "good, i will remind you in " + days + " days, on the " + format_date + "\n, to view your task click on view tasks");
                manage_tasks.insert_task(task_name, task_description, task_dueDate, task_status);

                question.Clear();
                return;

            }//end of the reminder if

            // Process each word
            foreach (string word in words)
            {
                // Skip very short words or ignored words
                if (word.Length < 3 || ignore.Contains(word.ToLower()))
                    continue;

                per_word.Clear();

                //start of interests

                if (word.Contains("interested"))
                {
                    string store_interests = string.Empty;
                    bool found_interest = false;

                    HashSet<string> currentInterests = new HashSet<string>();

                    foreach (string interest in words)
                    {
                        // CLEAN INPUT
                        string clean = interest.ToLower().Trim();
                        clean = Regex.Replace(clean, @"[^a-zA-Z0-9\s]", "");

                        // FILTER NOISE WORDS
                        if (!ignore.Contains(clean) && clean != "interested" && clean != "and" && clean != "in" && clean.Length >= 3)
                        {
                            found_interest = true;
                            currentInterests.Add(clean);
                        }
                    }

                    // prepare interests
                    store_interests = string.Join(", ", currentInterests);

                    if (found_interest && !string.IsNullOrWhiteSpace(store_interests))
                    {
                        string filename = "interested_topic.txt";
                        bool userFound = false;

                        if (File.Exists(filename))
                        {
                            string[] lines = File.ReadAllLines(filename);

                            for (int i = 0; i < lines.Length; i++)
                            {
                                if (lines[i].StartsWith(username))
                                {
                                    userFound = true;

                                    //get all the interests
                                    string existing = lines[i].Replace(username + " interested in:", "").ToLower();

                                    HashSet<string> existingSet = new HashSet<string>(existing.Split(',').Select(x => x.Trim()).Where(x => x != ""));

                                    foreach (string item in currentInterests)
                                    {
                                        existingSet.Add(item);
                                    }

                                    string finalList = string.Join(", ", existingSet);

                                    lines[i] = username + " interested in: " + finalList;
                                    File.WriteAllLines(filename, lines);

                                    message += "great, i added " + store_interests + " to your interests and ";
                                    break;
                                }
                            }
                        }

                        if (!userFound)
                        {
                            File.AppendAllText(
                                filename,
                                username + " interested in: " + store_interests + "\n"
                            );

                            message += "great, i will remember that you are interested in " + store_interests + " and ";
                        }
                    }
                    else
                    {
                        message += "Please specify what you're interested in (e.g., 'I am interested in cybersecurity')";
                    }
                }

                //end of interests

                // Search for matching answers
                bool wordFound = false;
                foreach (string answer in reply)
                {
                    if (answer.ToLower().Contains(word))
                    {
                        wordFound = true;
                        per_word.Add(answer);
                    }
                }

                if (wordFound && per_word.Count > 0)
                {
                    found = true;
                    int indexing = indexer.Next(0, per_word.Count);
                    answers_found.Add(per_word[indexing]);
                }
            }

            // Show responses or hand off to the NLP fallback
            if (found && answers_found.Count > 0)
            {
                // Remove duplicate answers
                answers_found = answers_found.Distinct().ToList();

                foreach (string per_answer in answers_found)
                {
                    message += per_answer + "\n";
                    task_description += per_answer + " ";
                }

                error_method("LikhoAi", message.TrimEnd('\n'));

                chats.ScrollIntoView(chats.Items[chats.Items.Count - 1]);
            }
            else
            {
                //BUG FIX: CheckAndLearn was previously called twice in a row for the same
                //input (once into an unused "response" variable, then again for the real
                //reply). Since CheckAndLearn writes to disk as a side effect, that duplicated
                //every "unknown question" / "learned question" log entry. It is now called
                //once, and the current user's name is passed through so interests get
                //attributed to the right person instead of the literal default "user".
                string unknownResponse = train_ai.CheckAndLearn(questions, username);

                error_method("LikhoAi", unknownResponse);
            }

            // Clear the input box
            question.Clear();

        }//end of ai_chat method

        //method to remove special characters
        private string RemoveSpecialCharacters(string input)
        {
            if (string.IsNullOrWhiteSpace(input))
                return string.Empty;

            StringBuilder sanitized = new StringBuilder();

            foreach (char c in input)
            {
                if (char.IsLetterOrDigit(c) || char.IsWhiteSpace(c) || c == '\'' || c == '-')
                {
                    sanitized.Append(c);
                }
                else
                {
                    sanitized.Append(' ');
                }
            }

            string result = sanitized.ToString();
            result = Regex.Replace(result, @"\s+", " ").Trim();

            return result;
        }//end of method to remove special characters

        //method count to show interests randomly
        private void auto_show_interest()
        {
            if (counting == 3)
            {
                string filename = "interested_topic.txt";

                if (File.Exists(filename))
                {
                    string[] lines = File.ReadAllLines(filename);

                    foreach (string line in lines)
                    {
                        if (line.StartsWith(username))
                        {
                            int colonIndex = line.IndexOf("interested in:");
                            if (colonIndex >= 0)
                            {
                                string interests = line.Substring(colonIndex + 14).Trim();

                                error_method("LikhoAi", "Just a reminder, you are interested in " + interests + " and ");
                                ai_check(interests);
                                break;
                            }
                        }
                    }
                }

                counting = 0;
            }
            else
            {
                counting += 1;
            }
        }//end of count interest method

        // error method with chat-bubble formatting
        private void error_method(string name, string message)
        {
            Border messageBorder = new Border
            {
                Margin = new Thickness(0, 2, 0, 2),
                Padding = new Thickness(5, 3, 5, 3),
                CornerRadius = new CornerRadius(5)
            };

            //BUG FIX: this used to compare a lower-cased name against the mixed-case
            //literal "LikhoAi", which Contains() could never match. Comparing against the
            //lower-case form fixes the bot's chat bubbles always falling through to the
            //"user" styling.
            bool isBot = name.ToLower().Contains("likhoai") || name.ToLower().Contains("chat");

            if (isBot)
            {// Light blue
                messageBorder.Background = new SolidColorBrush(Color.FromRgb(240, 248, 255));
                messageBorder.BorderBrush = new SolidColorBrush(Color.FromRgb(173, 216, 230));
            }
            else
            {    // Light gray
                messageBorder.Background = new SolidColorBrush(Color.FromRgb(245, 245, 245));
                messageBorder.BorderBrush = new SolidColorBrush(Color.FromRgb(211, 211, 211));
            }
            messageBorder.BorderThickness = new Thickness(1);

            TextBlock messageText = new TextBlock
            {
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(2)
            };

            Brush nameColor = isBot ? Brushes.DarkBlue : Brushes.DarkGreen;
            Brush messageColor = Brushes.Black;

            messageText.Inlines.Add(new Run
            {
                Text = name + ": ",
                Foreground = nameColor,
                FontWeight = FontWeights.Bold
            });

            messageText.Inlines.Add(new Run
            {
                Text = message,
                Foreground = messageColor
            });

            messageBorder.Child = messageText;
            chats.Items.Add(messageBorder);

            chats.ScrollIntoView(chats.Items[chats.Items.Count - 1]);
        }//end of error method

    }//end of class
}//end of namespace
